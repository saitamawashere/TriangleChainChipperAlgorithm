from flask import Flask, render_template, request

app = Flask(__name__)

# Fungsi untuk melakukan enkripsi ROT13
def encrypt_rot13(text):
    result = ""
    for char in text:
        if char.isalpha():
            ascii_offset = ord('a') if char.islower() else ord('A')
            encrypted_char = chr((ord(char) - ascii_offset + 13) % 26 + ascii_offset)
            result += encrypted_char
        else:
            result += char
    return result

# Fungsi untuk melakukan enkripsi TCC
def encrypt_tcc(text):
    result = ""
    for char in text:
        ascii_value = ord(char)
        encrypted_value = ascii_value ^ 0x5A
        result += chr(encrypted_value)
    return result

# Rute untuk halaman utama
@app.route('/')
def index():
    return render_template('index.html')

# Rute untuk mengolah data pengguna
@app.route('/process', methods=['POST'])
def process():
    text = request.form.get('text', '')
    # Melakukan enkripsi dengan algoritma ROT13
    encrypted_rot13 = encrypt_rot13(text)
    # Melakukan enkripsi dengan algoritma TCC
    encrypted_tcc = encrypt_tcc(text)
    return render_template('result.html', rot13=encrypted_rot13, tcc=encrypted_tcc)

if __name__ == '__main__':
    app.run(debug=True)
