# Perhitungan Algoritma Triangle Chipper Chaining
# Nama: Satria Aditama Prasetya - TI UIN 21 (11210910000019)
def triangle_chain_cipher(input_text):
    result = ""
    for i in range(len(input_text)):
        if input_text[i].isalpha():
            char = input_text[i].lower()
            position = ord(char) - ord('a')
            encrypted_position = (position * (position + 1)) // 2
            encrypted_char = chr(encrypted_position % 26 + ord('a'))
            result += encrypted_char
        else:
            result += input_text[i]
    return result


# Meminta input teks dari pengguna
input_text = input("Masukkan teks: ")

# Melakukan enkripsi menggunakan Triangle Chain Cipher
encrypted_text = triangle_chain_cipher(input_text)

# Menampilkan hasil enkripsi
print("Hasil enkripsi: " + encrypted_text)
